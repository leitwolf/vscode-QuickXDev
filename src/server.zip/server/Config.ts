
import * as fs from 'fs';
import * as path from 'path';
import { URL } from 'url';

/**
 * 插件配置，定义于package.json文件中
 */
interface Settings {
    root: string;
}
// 当前插件配置选项，要跟client发送过来的一样
interface MySettings {
    quickxdev: Settings;
}

class Config0 {

    // 设置
    private _settings: Settings;
    // 项目根目录uri
    private _workspaceRoot: string;
    // 是否是Quick-cocos2dx项目
    private _isQuickX: boolean = false;

    constructor() {
    }
    /**
     * 初始化
     */
    public initWorkspace(workspaceRoot: string) {
        this._workspaceRoot = workspaceRoot;
        let cocos2d = workspaceRoot + "/src/cocos/cocos2d";
        this._isQuickX = fs.existsSync(new URL(cocos2d));
    }
    /**
     * 初始化配置
     */
    public initSettings(settings: any) {
        console.log("init setting");
        let s = <MySettings>settings;
        this._settings = s.quickxdev;
        if (!this.quickRoot) {
            // 没有设置root，则从系统中取
        }
    }
    /**
     * 配置选项
     */
    public get settings(): Settings {
        return this._settings;
    }
    /**
     * Quick-Cocos2dx 根目录
     */
    public get quickRoot(): string {
        return this._settings.root;
    }
    /**
     * 项目目录
     */
    public get workspaceRoot(): string {
        return this._workspaceRoot;
    }
    /**
     * 是否是quick-cocos2dx项目
     */
    public get isQuickX(): boolean {
        return this._isQuickX;
    }
}
/**
 * 配置文件管理
 */
export const Config = new Config0();