import { IConnection, MessageType, ShowMessageParams, Diagnostic } from "vscode-languageserver";


/**
 * 服务端功能集合，主要提供一些基础的功能
 */
class Proxy0 {

    private _connetion: IConnection;

    constructor() {
    }

    /**
     * 初始化
     */
    public init(conn: IConnection): void {
        this._connetion = conn;
    }

    // ===========显示消息==========
    /**
     * 显示消息
     * @param type 消息类型
     * @param message 消息实体
     */
    public showMessage(type: MessageType, message: string) {
        let messageParams = {
            type: type,
            message: message
        };
        this._connetion.sendNotification("window/showMessage", <ShowMessageParams>messageParams);
    }
    /**
     * 显示Info消息
     * @param message 消息
     */
    public showMessageInfo(message: string) {
        this.showMessage(MessageType.Info, message);
    }
    /**
     * Log消息
     * @param message 消息
     */
    public showMessageLog(message: string) {
        this.showMessage(MessageType.Log, message);
    }
    /**
     * 显示Warning消息
     * @param message 消息
     */
    public showMessageWarning(message: string) {
        this.showMessage(MessageType.Warning, message);
    }
    /**
     * 显示Error消息
     * @param message 消息
     */
    public showMessageError(message: string) {
        this.showMessage(MessageType.Error, message);
    }
    // ===================

    /**
     * 与客户端的连接
     */
    public get connection(): IConnection {
        return this._connetion;
    }
}
/**
 * 服务端代码，基础功能集合
 */
export const ServerProxy = new Proxy0();