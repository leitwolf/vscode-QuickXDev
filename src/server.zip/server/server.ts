/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */
'use strict';
import { CompletionItem, createConnection, IConnection, InitializeResult, ProposedFeatures, TextDocumentPositionParams, TextDocumentSyncKind } from 'vscode-languageserver';
import { Builder } from './Builder';
import { Config } from './Config';
import { ServerProxy } from './Proxy';


// 建立连接
let connection: IConnection = createConnection(ProposedFeatures.all);

// 初始化
connection.onInitialize((params): InitializeResult => {
	// let str="aa.cc:bb."
	// let arr = str.split(/\.|\:/);
	// console.log("---paths",arr);

	console.log("Init project: ",params.rootUri);
	Config.initWorkspace(params.rootUri);
	ServerProxy.init(connection);
	Builder.initWorkspace();
	return {
		// 返回服务端提供的功能
		capabilities: {
			// 文档内容同步类型，无|全部|增量
			textDocumentSync: TextDocumentSyncKind.Full,
			// 告诉客户端支持代码自动完成
			completionProvider: {
				resolveProvider: true,
				triggerCharacters: [".", ":"]
			}
		}
	}
});

// 配置初始化或内容改变时
connection.onDidChangeConfiguration((change) => {
	Config.initSettings(change.settings);
});
connection.onDidChangeWatchedFiles((_change) => {
	// Monitored files have change in VSCode
	console.log('We recevied an file change event');
});

// 自动完成
connection.onCompletion((_textDocumentPosition: TextDocumentPositionParams): CompletionItem[] => {
	let uri = _textDocumentPosition.textDocument.uri;
	let line = _textDocumentPosition.position.line;
	let character = _textDocumentPosition.position.character;
	// console.log(_textDocumentPosition);
	return Builder.handleComplete(uri, line, character);

	// return [
	// 	{
	// 		label: 'TypeScript',
	// 		kind: 1,
	// 		detail: "非常好",
	// 		// filterText:"bbb",
	// 		// insertTextFormat: 2,
	// 		// insertText: "TypeScri$1bbb,\n${2:ccc})",
	// 		// documentation: "很好啊，\r\n非常好啊"
	// 	},
	// 	{
	// 		label: 'tavascript',
	// 		kind: CompletionItemKind.Text,
	// 		// detail: "非常好1",
	// 		// documentation: "很好啊1，\r\n非常好啊"
	// 	}
	// ]
});

// 当上下选中自动完成选项时要显示的更多信息
connection.onCompletionResolve((item: CompletionItem): CompletionItem => {
	return item;
});

/**
 * 内容改变时
 */
connection.onDidChangeTextDocument((params) => {
	if (params.contentChanges.length > 0) {
		for (let i = 0; i < params.contentChanges.length; i++) {
			const data = params.contentChanges[i].text;
			Builder.parseCode(params.textDocument.uri, data);
		}
	}
});

// 开始监听
connection.listen();
