import { CompletionItem } from "vscode-languageserver";

// 基础项
export interface DocItem {
    name: string;
    completion: CompletionItem;
    items: DocItem[];
    // 引用，c=cc Node=c.Node => c.refers=[cc] Node.refers=[c.Node,cc.Node]
    refers:DocItem[];
    // 所在位置，lua只有两项[line,col]，c++有三项[line,col,src]
    loc: any[];
}
// 一个文档
export interface FileDoc {
    url: string;
    // 全局变量
    globals: DocItem[];
    // 局部变量
    locals: DocItem[];
}
