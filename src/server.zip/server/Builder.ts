import * as fs from 'fs';
import * as luaparse from "luaparse";
import * as rd from 'rd';
import { CompletionItem } from "vscode-languageserver";
import URI from 'vscode-uri';
import { AstParser } from './AstParser';
import { Config } from './Config';
import { DocItem, FileDoc } from './types';
import { URL } from 'url';


// luaparse解析参数
interface ParseOption {
    scope: boolean;
    locations: boolean;
    ranges: boolean;
    luaVersion: string;
}

/**
 * 生成自动列表
 */
class Builder0 {

    // 解析参数
    private _option: ParseOption;

    // c++预加载列表
    private _cppList: DocItem[];
    // 文档列表，包括系统函数
    private _fileList: FileDoc[];
    // 客户端最后发送的文字，自动完成时不用重复加载
    private _lastText: string = "";

    // 是否已初始化了，解析完项目内所有的lua文件
    private _inited: boolean = false;
    private _total: number;
    private _count: number;

    constructor() {
        this._option = <ParseOption>{};
        this._option.scope = true;
        this._option.locations = true;
        this._option.ranges = false;
        this._option.luaVersion = '5.1';

        this._cppList = [];
        this._fileList = [];
    }
    /**
     * 初始化整个工作区，解析所有的lua代码文件
     */
    public initWorkspace(): void {
        let rootPath = URI.parse(Config.workspaceRoot).fsPath;
        let paths: string[] = rd.readFileFilterSync(rootPath, /\.lua$/);
        this._total = paths.length;
        this._count = 0;
        for (let i = 0; i < paths.length; i++) {
            let filename = paths[i];
            this.readFile(filename);
        }
    }
    /**
     * 读取一个文件
     * @param filepath 
     */
    private readFile(filepath: string): void {
        console.log("read", filepath);
        let s = this;
        fs.readFile(filepath, "utf-8", function (err: NodeJS.ErrnoException, data: string) {
            s._count++;
            let fileuri = URI.file(filepath).toString();
            s.parse(fileuri, data);
            if (s._count >= s._total) {
                s._inited = true;
                console.log("inited");
            }
        });
    }
    /**
     * 真正解析
     * @param uri 
     * @param data 
     */
    private parse(uri: string, data: string) {
        try {
            let ast = luaparse.parse(data, this._option);

            let p = new URL(Config.workspaceRoot + "/p.json");
            fs.writeFileSync(p, JSON.stringify(ast));

            let file = AstParser.parseDoc(ast);
            file.url = uri;

            p = new URL(Config.workspaceRoot + "/a2.json");
            fs.writeFileSync(p, JSON.stringify(file));
            // console.log("write a2");

            // 先删除之前的
            for (let i = 0; i < this._fileList.length; i++) {
                const f = this._fileList[i];
                if (f.url == uri) {
                    this._fileList.splice(i, 1);
                    break;
                }
            }
            this._fileList.push(file);
        } catch (error) {
            // console.log(error);
        }
    }
    /**
     * 解析代码内容，一般是内容改变时
     */
    public parseCode(uri: string, code: string) {
        if (this._inited) {
            this._lastText = code;
            this.parse(uri, code);
        }
    }

    /**
     * 处理生成自动完成列表
     * @param uri 
     * @param line 从0开始
     * @param character 
     */
    public handleComplete(uri: string, line: number, character: number): CompletionItem[] {
        // 从lastText中查找对应的关键字
        let lastText = this._lastText;
        if (lastText && lastText.length > 0) {
            // 文档所有行数
            let lines = lastText.split("\n");
            if (lines.length > line) {
                let curLine = lines[line];
                if (curLine.length >= character) {
                    // 光标之前的内容，最后一个空格之后的内容
                    let prevContent = curLine.substring(0, character);
                    let lastBlank = curLine.lastIndexOf(" ");
                    if (lastBlank != -1) {
                        prevContent = curLine.substring(lastBlank + 1, character);
                    }
                    // console.log("prevContent", prevContent);
                    // 是否含有单词字符，没有单词字符则不是
                    let index = prevContent.search(/\w+/);
                    if (index >= 0) {
                        return this.handleCompleteText(uri, prevContent);
                    }
                }
            }
        }
        return [];
    }
    /**
     * 对一段文字进行补全
     * @param uri 
     * @param str 
     */
    private handleCompleteText(uri: string, str: string): CompletionItem[] {
        let completions: CompletionItem[] = [];
        // 对str进行分析，取父路径的列表，如aa.bb.cc取aa.bb下的items
        let paths = str.split(/\.|\:/);
        // console.log("paths",arr);
        // 最后一个不算，不管是空还是有文字的
        paths.pop();
        // console.log("paths",arr);

        this.findCompletions(paths, this._cppList, completions);
        for (let i = 0; i < this._fileList.length; i++) {
            const f = this._fileList[i];
            this.findCompletions(paths, f.globals, completions);
            if (f.url == uri) {
                this.findCompletions(paths, f.locals, completions);
            }
        }
        // console.log("---------");
        // console.log(completions);
        return completions;
    }
    /**
     * 从列表中找到对应路径的Completion
     * @param paths 
     * @param list 
     * @param completions 
     */
    private findCompletions(paths: string[], list: DocItem[], completions: CompletionItem[]) {
        if (!paths || paths.length == 0) {
            // 没有则选择第一个
            this.pickItems(list, completions, false);
            return;
        }
        // 找到的最后点
        let lastItem: DocItem;
        for (let i = 0; i < paths.length; i++) {
            const p = paths[i];
            // 是否有相关节点
            let has = false;
            for (let j = 0; j < list.length; j++) {
                const item = list[j];
                if (item.name == p) {
                    if (item.items && item.items.length > 0) {
                        list = item.items;
                        lastItem = item;
                        has = true;
                        break;
                    }
                    else {
                        // 当前路径节点下没有子项，则无可加入的Completion
                        return;
                    }
                }
            }
            if (!has) {
                // 没有当前节点，不符合，pass
                return;
            }
        }
        // 有这一路径的节点
        if (lastItem) {
            if (lastItem.items && lastItem.items.length > 0) {
                this.pickItems(lastItem.items, completions, false);
            }
        }
    }
    /**
     * 多个DocItem放入列表中
     * @param items 
     * @param completions 
     * @param pickChildren 
     */
    private pickItems(items: DocItem[], completions: CompletionItem[], pickChildren: boolean) {
        for (let i = 0; i < items.length; i++) {
            this.pickItem(items[i], completions, pickChildren);
        }
    }
    /**
     * 把一个DocItem放置到列表中
     * @param item 
     * @param completions 
     * @param pickChildren 是否添加子项
     */
    private pickItem(item: DocItem, completions: CompletionItem[], pickChildren: boolean): void {
        completions.push(item.completion);
        if (pickChildren && item.items && item.items.length > 0) {
            this.pickItems(item.items, completions, true);
        }
    }
}
/**
 * 解析器，导出单例
 */
export const Builder = new Builder0();